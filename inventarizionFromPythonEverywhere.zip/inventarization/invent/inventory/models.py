from django.db import models

# Create your models here.
class Inventory(models.Model):
    status_choices = [
        ('В работе', 'В работе'),
        ('В ремонте', 'В ремонте'),
        ('В резерве', 'В резерве'),
        ('Списан', 'Списан')
    ]
    status = models.CharField('Статус', max_length=50, choices=status_choices)
    housing = models.TextField('корпус')
    floor = models.IntegerField('этаж')
    room = models.TextField('кабинет')
    type_choices = [
        ('факс', 'факс'),
        ('маршрутизатор', 'маршрутизатор'),
        ('мфу', 'мфу'),
        ('монитор', 'монитор'),
        ('моноблок', 'моноблок'),
        ('ноутбук', 'ноутбук'),
        ('проектор', 'проектор'),
        ('сканер', 'сканер'),
        ('шредер', 'шредер'),
        ('системный блок', 'системный блок'),
        ('копир', 'копир'),
        ('другое', 'другое'),
    ]
    type = models.TextField('Тип устройства', choices=type_choices)
    serial_number = models.TextField('серийный номер устройства')
    inventory_number = models.IntegerField('инвентарный номер')
    unit = models.TextField('отдел')
    dept = models.TextField('отделение')
    mol = models.TextField('материально-ответственное лицо')
    fio_allow = models.TextField('ФИО допущенных к работе с устройством')
    buh_inv_number = models.TextField('бухгалтерский инв.номер')
    year = models.DateField('год закупки')
    tn_numberdatas = models.IntegerField('номер товарной накладной')
    date = models.DateField('Дата товарной накладной')
    price = models.TextField('закупочная стоимость')
    cause = models.TextField('основание для закупки')
    gk_number = models.TextField('номер контракта')
    gk_date = models.DateField('дата контракта')
    gk_code = models.TextField('шифр контракта')
    dp_number = models.TextField('номер договора поставки')
    dp_date = models.DateField('дата договора поставки')
    safe_doc = models.URLField('файл (хранится ссылка на файл) сохранной расписки', max_length=200, null=True)
    note = models.TextField('заметка')
    history = models.TextField('история (перемещения, замена комплектующих)')

    def __str__(self):
        return self.type

    def get_absolute_url(self):
        return f'/inventory/{self.id}'

    class Meta:
        verbose_name = 'Инвентаризацонная база'
        verbose_name_plural = 'Инвентаризацонная база'