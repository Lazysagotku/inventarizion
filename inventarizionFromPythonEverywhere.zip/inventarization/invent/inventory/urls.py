from django.urls import path
from . import views

urlpatterns = [
    path('', views.inventory_home, name='inventory_home'),
    path('create', views.create, name='create'),
    path('/<int:pk>', views.InvDeteilView.as_view(), name='inv-deteil'),
    path('/<int:pk>/update', views.InvUpdateView.as_view(), name='inv-update'),
    path('/<int:pk>/delete', views.InvDeleteView.as_view(), name='inv-delete')
]