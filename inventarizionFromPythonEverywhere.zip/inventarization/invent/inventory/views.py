from django.shortcuts import render,redirect
from .models import Inventory
from .forms import InventoryForm
from django.views.generic import DetailView, UpdateView, DeleteView, ListView
from django.db.models import Q



# Create your views here.
def inventory_home(request):
    search_query = request.GET.get('search', '')

    if search_query:
        inv = Inventory.objects.filter(Q(type__icontains=search_query) | Q(status__icontains=search_query) | Q(housing__icontains=search_query) | Q(floor__icontains=search_query) | Q(room__icontains=search_query) | Q(serial_number__icontains=search_query) | Q(inventory_number__icontains=search_query) | Q(unit__icontains=search_query) | Q(dept__icontains=search_query) | Q(mol__icontains=search_query))
    else:
        inv = Inventory.objects.all()
    return render(request, 'inventory/inventory_home.html', {'inv': inv})

    #search_query_type = request.GET.get('search_type', '')
    #search_query_status = request.GET.get('search_status', '')
    #search_query_housing = request.GET.get('search_housing', '')
#
    #if search_query_type:
    #    inv = Inventory.objects.filter(Q(type__icontains=search_query_type))
    #if search_query_status:
    #    inv = Inventory.objects.filter(Q(status__icontains=search_query_status))
#
    #else:
    #    inv = Inventory.objects.all()
    #return render(request, 'inventory/inventory_home.html', {'inv': inv})
#
    #search_query_status = request.GET.get('search_status', '')
    #if search_query_status:
    #    inv = Inventory.objects.filter(Q(status__icontains=search_query_status))
    #else:
    #    inv = Inventory.objects.all()
    #return render(request, 'inventory/inventory_home.html', {'inv': inv})
#
    #search_query_housing = request.GET.get('search_housing', '')
    #if search_query_housing:
    #    inv = Inventory.objects.filter(Q(housing__icontains=search_query_housing))
    #else:
    #    inv = Inventory.objects.all()
    #return render(request, 'inventory/inventory_home.html', {'inv': inv})
#
    #search_query_floor = request.GET.get('search_floor', '')
    #if search_query_floor:
    #    inv = Inventory.objects.filter(Q(floor__icontains=search_query_floor))
    #else:
    #    inv = Inventory.objects.all()
    #return render(request, 'inventory/inventory_home.html', {'inv': inv})
#
    #search_query_room = request.GET.get('search_room', '')
    #if search_query_room:
    #    inv = Inventory.objects.filter(Q(room__icontains=search_query_room))
    #else:
    #    inv = Inventory.objects.all()
    #return render(request, 'inventory/inventory_home.html', {'inv': inv})
#
    #search_query_ss = request.GET.get('search_serial_number', '')
    #if search_query_ss:
    #    inv = Inventory.objects.filter(Q(serial_number__icontains=search_query_ss))
    #else:
    #    inv = Inventory.objects.all()
    #return render(request, 'inventory/inventory_home.html', {'inv': inv})
#
    #search_query_si = request.GET.get('search_inventory_number', '')
    #if search_query_si:
    #    inv = Inventory.objects.filter(Q(inventory_number__icontains=search_query_si))
    #else:
    #    inv = Inventory.objects.all()
    #return render(request, 'inventory/inventory_home.html', {'inv': inv})
#
    #search_query_unit = request.GET.get('search_unit', '')
    #if search_query_unit:
    #    inv = Inventory.objects.filter(Q(unit__icontains=search_query_unit))
    #else:
    #    inv = Inventory.objects.all()
    #return render(request, 'inventory/inventory_home.html', {'inv': inv})
#
    #search_query_dept = request.GET.get('search_dept', '')
    #if search_query_dept:
    #    inv = Inventory.objects.filter(Q(dept__icontains=search_query_dept))
    #else:
    #    inv = Inventory.objects.all()
    #return render(request, 'inventory/inventory_home.html', {'inv': inv})
#
    #search_query_mol = request.GET.get('search_mol', '')
    #if search_query_mol:
    #    inv = Inventory.objects.filter(Q(mol__icontains=search_query_mol))
    #else:
    #    inv = Inventory.objects.all()
    #return render(request, 'inventory/inventory_home.html', {'inv': inv})


class InvDeteilView(DetailView):
    model = Inventory
    template_name = 'inventory/deteils.html'
    context_object_name = 'inventory'

class InvUpdateView(UpdateView):
    model = Inventory
    template_name = 'inventory/update.html'
    form_class = InventoryForm


class InvDeleteView(DeleteView):
    model = Inventory
    success_url = '/inventory/'
    template_name = 'inventory/inv-delete.html'


def create(request):
    error = ''
    if request.method == 'POST':
        form = InventoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inventory_home')
        else:
            error = 'Ошибка в заполнении формы'

    form = InventoryForm()

    data = {
        'form': form,
        'error': error
    }

    return render(request, 'inventory/create.html', data)