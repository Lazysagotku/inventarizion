from .models import Inventory
from django.forms import ModelForm



class InventoryForm(ModelForm):
    class Meta:
        model = Inventory
        fields = ['status', 'housing', 'floor', 'room', 'type', 'serial_number', 'inventory_number', 'unit', 'dept', 'mol', 'fio_allow', 'buh_inv_number', 'year', 'tn_numberdatas', 'date', 'price', 'cause', 'gk_number', 'gk_date', 'gk_code', 'dp_number', 'dp_date', 'safe_doc', 'note', 'history']
